
package com.xixun;

public class RequestData {
	//public String type="commandXixunPlayer";
	//public Command command;
	public String type="commandXixunPlayer";
	public Command command = new Command();
}
