
package com.xixun;
import com.xixun.contract.model.ProgramsTask;

public class Command{
//	public String _type;
//	public String id;
//	//文件下载url = preDownloadURL + source.id
//	public String preDownloadURL;
//	//返回节目下载进度的url
//	public String notificationURL;
//	//需要播放的task内容
//	public ProgramsTask task;
	String _type = "PlayXixunProgramZip";
	String path = "/mnt/sdcard/program.zip"; //绝对路径
	String password = "";
}