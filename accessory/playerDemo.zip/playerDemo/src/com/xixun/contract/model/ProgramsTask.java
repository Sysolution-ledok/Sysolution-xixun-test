package com.xixun.contract.model;

import java.io.Serializable;
import java.util.List;

public class ProgramsTask implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -1826460787972724543L;
	public String _id;					//使用UUID赋值
	public String name;					//节目名
	public UserDepartment _department;	//部门id，空字符串
	public List<TaskItem> items;		
	public String executeDate; 			//定时下载的时间
	
	public String cmdId;				//命令ID，使用UUID赋值
}
