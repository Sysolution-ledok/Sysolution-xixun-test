package com.xixun.contract.model;

public class MultiLineText {
	public MultiLineText(MultiLineTextSource source){
		this.speed = source.speed;
		this.lineHeight = source.lineHeight;
		this.center = source.center;
		this.html = source.html;
		this.width = source.width;
		this.height = source.height;
		this.textAlign = source.textAlign;
		this.backgroundColor = source.backgroundColor;
	}
	public int width;					//窗口宽
	public int height;					//窗口高
	public int speed ;					//翻页速度
    public float lineHeight;			//文字行高
    public boolean center ;				//是否居中显示
    public String html ;				//html内容
    public String textAlign;			//文本对齐方式
    public String backgroundColor;		//窗口背景色
}
