package com.xixun.contract.model;

import java.io.Serializable;

public class WebURL extends Source implements Serializable
{
	//private static final long serialVersionUID = -34545990895L;
	//需要显示的页面URL路径
	public String url;
	//暂无实际意义
    public String data;
}
