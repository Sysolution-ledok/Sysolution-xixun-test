package com.xixun.contract.model;

import java.io.Serializable;
import java.util.List;

public class Schedule implements Serializable{
    
    public String name;							//事件表名字
				
    public DateType dateType;					//参考DateType
    
    public String startDate;					//起始日期
    
    public String endDate;						//结束日期
    
    public TimeType timeType;					//参考TimeType
    
    public String startTime;					//起始时间
    
    public String endTime;						//结束时间
    
    public FilterType filterType;				//如果不按月或按星期几过滤请赋值null，参考FilterType
    
    public List<Integer> weekFilter;			//Sunday=1
    
    public List<Integer> monthFilter;			//Jan=1
    
    private static final long serialVersionUID = -7546514654L;
}

