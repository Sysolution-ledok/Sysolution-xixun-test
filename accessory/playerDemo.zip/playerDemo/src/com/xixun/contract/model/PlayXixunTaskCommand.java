package com.xixun.contract.model;

public class PlayXixunTaskCommand {
	//public String executeData;
	public String id;
	public String preDownloadURL;
	public String notificationURL;
	public ProgramsTask task;
	public String _type;
}
