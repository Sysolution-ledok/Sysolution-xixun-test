
/*
忽略，需要改类型时填null
*/
package com.xixun.contract.model;

public enum FinishType {
	ByCount,
	ByTime
}