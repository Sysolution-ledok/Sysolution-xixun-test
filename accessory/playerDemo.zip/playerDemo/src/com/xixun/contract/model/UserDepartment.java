package com.xixun.contract.model;

import java.io.Serializable;

public class UserDepartment implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3954242281239991044L;
	public String _id;
	public String _company;
	public String name;
	public int priority;
}
