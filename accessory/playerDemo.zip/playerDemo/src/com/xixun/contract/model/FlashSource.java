
/*
这个类型用来包装一个flash素材
*/

package com.xixun.contract.model;

import java.io.Serializable;

@SuppressWarnings("deprecation")
public class FlashSource extends Source implements Serializable{

	private static final long serialVersionUID = -4460365841417533355L;
	public String mime;		//没有使用
}
