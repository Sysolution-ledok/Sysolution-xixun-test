
/*
这个类型用来包装一个图片素材，除了png，bmp，jpg文件，同时可以包装gif
*/

package com.xixun.contract.model;

import java.io.Serializable;

@SuppressWarnings("deprecation")
public class ImageSource extends Source implements Serializable{
	public String mime;		//包装gif图片时赋值"image/gif"，否则填入任意其他字符串，不要为null
	private static final long serialVersionUID = -70072231234654L;
}
