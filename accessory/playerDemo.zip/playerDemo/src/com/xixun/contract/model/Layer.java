
/*
一个时间轴，对应显示多层窗口中的一层
*/
package com.xixun.contract.model;

import java.io.Serializable;
import java.util.List;

@SuppressWarnings("deprecation")
public class Layer implements Serializable{
	
	public List<Source> sources;   //素材都需要加入到这个list里面
	public boolean repeat;			//如果该值为false，它会在播放时长到达后结束播放，否则他会循环播放直到list中最长的那个layer播放结束时结束播放
	private static final long serialVersionUID = -234242314654L;
}
