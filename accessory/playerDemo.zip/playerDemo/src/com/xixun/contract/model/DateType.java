
/*
定时播放时日期的定义，不建议使用。
*/
package com.xixun.contract.model;

public enum DateType{
	Range, 		//两个时间区间
	All			//全时段
}
