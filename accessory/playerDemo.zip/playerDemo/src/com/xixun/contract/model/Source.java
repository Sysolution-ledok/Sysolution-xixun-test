package com.xixun.contract.model;

import java.io.Serializable;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;
import com.fasterxml.jackson.annotation.JsonTypeInfo;


@SuppressWarnings("deprecation")
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "_type")
@JsonSubTypes(value = { @Type(value = ImageSource.class,name="Image"),
		@Type(value = VideoSource.class, name="Video"),
		//@Type(value = ClockData.class, name="AnalogClock"),
		//@Type(value = CountdownSource.class, name="Countdown"),
		@Type(value = SingleLineTextSource.class, name="SingleLineText"),
		@Type(value = MultiLineTextSource.class, name="MultiLineText"),
		//@Type(value = DigitalClockSource.class, name="DigitalClock"),
		@Type(value = FlashSource.class, name="Flash"),
		//@Type(value = AudioSource.class, name="Audio"),
		//@Type(value = WeatherSource.class, name="Weather")
})

public abstract class Source implements Serializable{
	public String id; 				//UUID进行赋值
	
	public String md5;				//素材如果有大小需要计算它的md5
	
	public String name;				//素材名字
    
    public int left;				//显示在左上角的坐标
    
    public int top;					
    
    public int width;				//宽高
    
    public int height;
    
    public long size;				//文件大小
    
    public int paddingBefore;		//无需关心
    
    public int playTime;			//起始播放时间
    
    public int timeSpan;			//持续播放时长
    
    public String url;				//从其他链接下载素材
    
    public String localPath;		//无需关心该属性
    
    public EffectType entryEffect;	//入场特效
    
    public int entryEffectTimeSpan; //入场特效播放时长
    
    public EffectType exitEffect;	//出场特效
    
    public int exitEffectTimeSpan;	//出场特效播放时长
    
    public int index;				//list中的索引值
    
    public Source(){
    	
    }
}
