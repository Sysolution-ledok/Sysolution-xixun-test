
/*
文字或窗口的显示位置
*/
package com.xixun.contract.model;

public enum DirectionType {
	Left,		//左边
	Right		//右边
}
