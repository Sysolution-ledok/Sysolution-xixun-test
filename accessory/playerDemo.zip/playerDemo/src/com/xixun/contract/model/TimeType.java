package com.xixun.contract.model;

public enum TimeType {
	Range,		//两个时间区间
	All			//整个时间段
}
