
/*
schedule中的可选项，用于限定定时播放
*/
package com.xixun.contract.model;

public enum FilterType {
	None,		//不过滤
	Week,		//按一周中某几天过滤
	Month		//按一年中某几个月过滤
}
