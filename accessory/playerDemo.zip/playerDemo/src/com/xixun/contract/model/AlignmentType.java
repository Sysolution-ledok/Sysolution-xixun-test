
/*
文字或窗口的对齐方式
*/

package com.xixun.contract.model;

public enum AlignmentType {
	Bottom,		//底部
	Center,		//中间
	Top			//顶部
}