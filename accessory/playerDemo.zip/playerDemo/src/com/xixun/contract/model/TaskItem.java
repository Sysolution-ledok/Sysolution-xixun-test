package com.xixun.contract.model;

import java.io.Serializable;
import java.util.List;

public class TaskItem implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8498744488474009758L;
	public String _id;					//UUID
	public Program _program;			//将包装好的节目赋值给他
	public int priority;				//节目优先级，0为最高优先级，数字越大优先级越小
	public int repeatTimes;				//重复次数
	public int version;					//版本参见program中的version
	public List<Schedule> schedules;	//可以为一个program添加多个定时段
}