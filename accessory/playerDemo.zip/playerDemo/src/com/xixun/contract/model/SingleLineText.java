package com.xixun.contract.model;

public class SingleLineText {
	public SingleLineText(SingleLineTextSource source){
		this.width= source.width;
		this.height= source.height;
		this.speed = source.speed;
		this.text = source.text;
		this.textBold = source.textBold;
		this.textColor = source.textColor;
		this.textSkewX = source.textSkewX;
		this.backColor = source.backColor;
		this.fontSize = source.fontSize;
		this.textUnderline = source.textUnderline;
		this.left = source.left;
		this.top = source.top;
		this.html = source.html;
	}
	public int width;
	public int height;
	public int speed ;
	public String text;
	public String textColor;
	public String backColor;
	public float textSkewX;
	public boolean textBold;
    public boolean textUnderline;
    public float fontSize;
    public int left;
    public int top;
    public String html;
}
