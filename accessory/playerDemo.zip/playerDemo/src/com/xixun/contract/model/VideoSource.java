package com.xixun.contract.model;
import java.io.File;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

/*
用户包装视频素材
*/

public class VideoSource extends Source implements Serializable{
	public String mime;		//无需赋值
	private static final long serialVersionUID = -42223536654L;
}
