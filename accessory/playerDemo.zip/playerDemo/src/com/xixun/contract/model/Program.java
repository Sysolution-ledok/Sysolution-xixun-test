
//包装节目的类

package com.xixun.contract.model;

import java.io.Serializable;
//import java.text.SimpleDateFormat;
//import java.util.ArrayList;
//import java.util.Date;
import java.util.List;
//import java.util.Timer;
//import java.util.TimerTask;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Program implements Serializable{
	@JsonProperty("_id")
	public String  id;					//请使用UUID赋值
	public String name;					//好记的名字
	public int width;					//节目宽
	public int height;					//节目高度
	public String departmentId;			//=空字符串
	public int repeat;					//该属性定义它和其他节目轮流播放时它在该轮连续重复次数，如果只有它一个节目，那么赋值1和赋值大于1等效。
	public List<Schedule> schedules;	//定时播放的时刻表
	public List<Layer> layers;			//所有素材都包含在该list中
	public boolean playSourceOnTime;	//无意义
	public String commandId;			//赋值null或空字符串
	public int priority; 				//决定多个节目时它的播放次序，数字越小优先级越高
	public int departmentPriority;		//无意义
	public boolean loop;				//无意义
	public boolean downloaded;			//false
	public long totalSize;				//将layers中的sources的size累加赋值给他，表示节目所有素材占用的空间
	public String savePath;				//无需赋值
	//如果为true，则该节目来自第三方接口，不是来自我们自己的web，二次开发请务必赋值为true
	public boolean isOthers; 
	public int __v; 					//=0
	public int version;					//2为简易节目，9为定点节目，其他为高级节目，请赋值其他。

	
	private static final long serialVersionUID = -10010514654L;
}
