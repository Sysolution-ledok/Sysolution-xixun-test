

/*
包装单行文本
*/
package com.xixun.contract.model;

import java.io.Serializable;


@SuppressWarnings("deprecation")
public class SingleLineTextSource  extends Source implements Serializable {
	private static final long serialVersionUID = 632442029297263250L;

	public int speed ;					//文字走动速度，指所有文字通过width一次的时长（单位秒）
	public int maxWidth;				//不用关心该属性
	public String html;					//单行文本做成html形式赋值给该属性
	public String text;					//显示的文字
	public String textColor;			//文字的颜色
	public String backColor;			//文字背景色
	public float textSkewX;				//斜体
	public boolean textBold;			//加粗
	public boolean textUnderline;		//下划线
	public float fontSize;				//字体大小
	public String data;					//无需关心
}
