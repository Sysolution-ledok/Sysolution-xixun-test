
package com.xixun;
import it.sauronsoftware.jave.Encoder;
import it.sauronsoftware.jave.MultimediaInfo;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.LinkedList;
import java.util.UUID;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;
import com.xixun.contract.model.*;


public class Test {
	
	public static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
	private OkHttpClient client = new OkHttpClient();
	
	//屏幕宽高和需要显示素材的宽高
	final static int w = 320;
	final static int h = 240;
	
	public static void main(String[] args) {
		//createProgram方法详细演示了创建一个轮播节目的过程
		Program p = createProgram();
		if(p == null){
			System.out.println("cannot create program");
		}
		try{
			//将创建好的节目实例转为json字符串保存到文件中，随素材文件（视频和图片）一起打包到压缩包中
			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
			  .configure(DeserializationFeature.WRAP_EXCEPTIONS, true);
			String json = mapper.writeValueAsString(p);
			saveAsFileWriter(json, "c:\\res\\program");
			//将c:\res目录中的文件生成压缩包，并命名为c:\Program.zip
			FileToZip.fileToZip("c:\\res", "c:\\", "Program");
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("cannot create program json");
			return;
		}
		//压缩文件生成成功即完成了整个节目制作，后面再调用realtime接口downloadFileToSD和PlayXixunProgramZip通知设备播放即可。
	}
	
	
	private static Program createProgram(){
		Program program = null;
		//从指定目录读取一个节目模板json，然后往里面装载需要显示的内容
		String template = readToString("c:\\res\\template");
		try{
			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
			  .configure(DeserializationFeature.WRAP_EXCEPTIONS, true);
			program = (Program)mapper.readValue(template, Program.class);
			//创建第一个图片素材
			Source s1 = createSource(0, "c:\\res\\1540025141626.jpg", 0, 0, w, h);
			//创建下一个图片素材
			Source s2 = createSource(0, "c:\\res\\1540782950535.jpg", 0, 0, w, h);
			//由于是轮播，需要将s2的开始播放时间playTime设置为s1播放结束的时间
			s2.playTime = s1.playTime + s1.timeSpan;
			//创建下一个视频素材
			Source s3 = createSource(0, "c:\\res\\1540782889488.mp4", 0, 0, w, h);
			//将s3的开始播放时间playTime设置为s2播放结束的时间，后面依次类推
			s3.playTime = s2.playTime + s2.timeSpan;
			//创建下一个视频素材
			Source s4 = createSource(0, "c:\\res\\out.mp4", 0, 0, w, h);
			s4.playTime = s3.playTime + s3.timeSpan;
			//创建下一个图片素材
			Source s5 = createSource(0, "c:\\res\\1540782953498.jpg", 0, 0, w, h);
			s5.playTime = s4.playTime + s4.timeSpan;
			//创建下一个图片素材
			Source s6 = createSource(0, "c:\\res\\1540809425044.jpg", 0, 0, w, h);
			s6.playTime = s5.playTime + s5.timeSpan;
			//将六个素材加入到节目中
			program.layers.get(0).sources.add(s1);
			program.layers.get(0).sources.add(s2);
			program.layers.get(0).sources.add(s3);
			program.layers.get(0).sources.add(s4);
			program.layers.get(0).sources.add(s5);
			program.layers.get(0).sources.add(s6);
			//设置节目总占用字节数
			program.totalSize = s1.size + s2.size + s3.size + s4.size + s5.size + s6.size;
		}catch(Exception e){
			e.printStackTrace();
		}
		return program;
	}
	
	private static Source createSource(int type, String filePath, int left, int top, int width, int height){
		//创建一个素材
		Source s = null;
		if(type == 0){
			//创建一个图片素材
			s = new ImageSource();
			//设置文件占用的字节数和播放时长
			try{
				File file = new File(filePath);
				if(file.exists()){
					s.size = file.length();
					//图片播放时长10s
					s.timeSpan = 10; 
				}
			}catch(Exception e){e.printStackTrace();}
		}
		else if(type == 1){
			//创建一个视频素材
			s = new VideoSource();
			//设置素材占用的字节数和播放时长
			try{
				File file = new File(filePath);
				if(file.exists()){
					s.size = file.length();
					//设置视频播放时长
					s.timeSpan = (int)ReadVideoTime(file);
				}
			}catch(Exception e){e.printStackTrace();}
		}else return s;
		s.left = left;
		s.top = top;
		s.width = width;
		s.height = height;
		s.id = UUID.randomUUID().toString();
		s.name = "";
		return s;
	}
	
	
	public static String readToString(String fileName) {
        String encoding = "UTF-8";  
        File file = new File(fileName);  
        Long filelength = file.length();  
        byte[] filecontent = new byte[filelength.intValue()];  
        try {  
            FileInputStream in = new FileInputStream(file);  
            in.read(filecontent);  
            in.close();  
        } catch (FileNotFoundException e) {  
            e.printStackTrace();  
        } catch (IOException e) {  
            e.printStackTrace();  
        }  
        try {  
            return new String(filecontent, encoding);  
        } catch (UnsupportedEncodingException e) {  
            System.err.println("The OS does not support " + encoding);  
            e.printStackTrace();  
            return null;  
        }  
    }
	
	private static void saveAsFileWriter(String content, String savePath) {
 
	 FileWriter fwriter = null;
	 try {
	  fwriter = new FileWriter(savePath);
	  fwriter.write(content);
	 } catch (IOException ex) {
	  ex.printStackTrace();
	 } finally {
	  try {
	   fwriter.flush();
	   fwriter.close();
	  } catch (IOException ex) {
	   ex.printStackTrace();
	  }
	 }
	}
	
	public String post(String url, String json) throws IOException {
		  RequestBody body = RequestBody.create(JSON, json);
		  Request request = new Request.Builder()
		      .url(url)
		      .post(body)
		      .build();
		  Response response = client.newCall(request).execute();
		  return response.body().string();
	}
	
	private static long ReadVideoTime(File source) {
		Encoder encoder = new Encoder();
		try {
			MultimediaInfo m = encoder.getInfo(source);
			return m.getDuration()/1000;
		}catch(Exception e){
			return 0;
		}
	}
}
